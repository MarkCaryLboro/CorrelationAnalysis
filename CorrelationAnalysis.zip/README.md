Battery testing facility correlation analysis package

Classes:

anova
allowableTestTypes
correlationAnalysis
correlationDesign
capacityTest
capacityTestAnalysis
correlationDataStore
correlationEM
correlationModel
correlationReport
correlationVariableType
mle
pulseTest
pulseData
pulseDesign
rateTest
rateData
rateDesign
capacityTest

Functions:

capacityTestAnalysis
pulseTestAnalysis
rateTestAnalysis
