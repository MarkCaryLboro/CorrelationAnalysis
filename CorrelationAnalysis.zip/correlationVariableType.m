classdef correlationVariableType < int8
    enumeration
        CONTINUOUS  (0)
        CATEGORICAL (1)
    end % enumeration
end % VariableType