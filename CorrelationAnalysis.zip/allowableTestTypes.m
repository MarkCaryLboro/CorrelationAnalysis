classdef allowableTestTypes < int8
    enumeration
        Rate            ( 0 )
        Pulse           ( 1 )
        Capacity        ( 2 )
    end
end % allowableTestTypes