classdef correlationEM < mle
    % implements Expectation Maximsation algorithm for repeated
    % measurements model
    
    
end % correlationEM