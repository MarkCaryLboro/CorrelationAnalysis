classdef mleAlgorithms < int8
    
    enumeration
        IGLS    ( 1 )
        EM      ( 2 )
        MLE     ( 3 )
    end
    
end % mleAlgorithms