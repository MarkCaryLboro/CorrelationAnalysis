classdef correlationFacility < int8
    enumeration
        Birmingham  (1)
        Imperial    (2)
        Lancaster   (3)
        Oxford      (4)
        Warwick     (5)
    end
end % correlationFacility