classdef pulseData < correlationDataStore
    
    properties ( Constant = true )
        DataType            allowableTestTypes      = "Pulse"     
        FileFormats         string                  = ".xlsx"
    end % constant properties    
    
    methods  
    end % constructor and ordinary methods
end % classdef