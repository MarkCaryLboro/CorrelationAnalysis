classdef igls < mle
end % igls